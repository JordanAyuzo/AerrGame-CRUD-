create function xchn_mayus() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (TG_OP = 'INSERT') THEN
            new.nombre := upper(new.nombre);
            new.clasificacion := upper(new.clasificacion);
            new.descripcion := upper(new.descripcion);
            new.genero := upper(new.genero);
        ELSIF (TG_OP = 'UPDATE') THEN
            new.nombre := upper(new.nombre);
            new.clasificacion := upper(new.clasificacion);
            new.descripcion := upper(new.descripcion);
            new.genero := upper(new.genero);
        END IF;
        RETURN NEW;
    END;
$$;

alter function xchn_mayus() owner to regrob261;

