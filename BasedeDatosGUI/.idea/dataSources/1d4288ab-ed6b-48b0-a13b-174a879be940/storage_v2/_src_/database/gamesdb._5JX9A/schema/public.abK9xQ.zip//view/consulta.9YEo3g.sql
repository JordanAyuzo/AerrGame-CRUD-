create view consulta(nickname, nombre, fecha_nacimiento, correo) as
SELECT usuario.nickname,
       usuario.nombre,
       usuario.fecha_nacimiento,
       usuario.correo
FROM usuario;

alter table consulta
    owner to regrob261;

