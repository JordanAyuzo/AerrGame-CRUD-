create view consulta(nombre, clasificacion, descripcion, genero) as
SELECT juego.nombre,
       juego.clasificacion,
       juego.descripcion,
       juego.genero
FROM juego;

alter table consulta
    owner to regrob261;

