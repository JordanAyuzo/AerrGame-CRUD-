create view datos(nombre, clasificacion, descripcion, genero) as
SELECT juego.nombre,
       juego.clasificacion,
       juego.descripcion,
       juego.genero
FROM juego;

alter table datos
    owner to regrob261;

